//var to use as number
var s = 59;
var resulte;
var remaining;
var x = false;
var Interval;



//for changine the style of input
var input = document.querySelector("input");

//buttons
var saveBtn = document.getElementById("save-btn");
var startBtn = document.getElementById("start-btn");
var stopBtn = document.getElementById("stop-btn");
var resetBtn = document.getElementById("reset-btn");


//interval var
var Interval;

//saveBtn function
saveBtn.addEventListener("click", function() {


    //input element
    var inputEl = Math.floor(document.getElementById("input").value);





    //adding and removing classes 
    startBtn.removeAttribute("disabled");
    startBtn.classList.remove("click-btn");
    startBtn.classList.add("button");
    resetBtn.removeAttribute("disabled");
    resetBtn.classList.remove("click-btn");
    resetBtn.classList.add("button");
    saveBtn.setAttribute("disabled", "");
    saveBtn.classList.add("click-btn");
    saveBtn.classList.remove("button")
    input.classList.add("click-btn");
    input.setAttribute("disabled", "");




    //statment for wrong inputs
    if(inputEl == ""){
        location.reload();
        alert("Add a Number");        
    }else{

    //countdown
    var min =  document.getElementById("min");
    var sec =  document.getElementById("sec");

    //Calculation
    resulte = Math.floor(inputEl / 60);
    remaining = inputEl % 60;

    //statments for calculation
    if(inputEl < 0){
        alert("Incorect");
        location.reload()
    }else{
    if(resulte < 10){
        min.innerHTML = "0" + resulte;
    }else if(resulte >= 60 || resulte <= 60 ){
        min.innerHTML = resulte;
    }
    if(remaining < 10){
        sec.innerHTML = "0" + remaining;
    }else{
        sec.innerHTML = remaining;
    }


    //startBtn for start countdown
    startBtn.addEventListener("click", () => {

    //calling function 
       Interval = setInterval(stratTimer,1000);

    // adding and removing classes
       startBtn.classList.remove("button");
       startBtn.classList.add("click-btn");
       input.classList.add("start-saveing");
       stopBtn.removeAttribute("disabled");
       stopBtn.classList.remove("click-btn");
       stopBtn.classList.add("button");
   
    },{once:true});

    //main funciton 
    function stratTimer(){
        if(remaining === 0){
            if(resulte === 0){
                clearInterval(Interval)
                sec.innerHTML = "00";

                //addin, remove classes
                stopBtn.setAttribute("disabled", "");
                stopBtn.classList.add("click-btn");
                stopBtn.classList.remove("button");

                //playing audio
                    let audio = new Audio("./123.mp3")
                    audio.play()
                
            }else if(resulte <= 10){
                remaining = s;
                sec.innerHTML = s;
                resulte--;
                min.innerHTML = "0" + resulte;
            }else if(resulte >= 10){
                resulte--;
                remaining = s;
                min.innerHTML = resulte;
            }else{
                resulte--;
                remaining = s;
                min.innerHTML = resulte;
            }
        }else if(remaining <= 10){
            remaining--;
            sec.innerHTML = "0" + remaining
        }else{
            remaining--;
            sec.innerHTML = remaining;
        }

    }

    //stopBtn 
    stopBtn.addEventListener("click", () => {
        if(x === false){
        clearInterval(Interval)
        stopBtn.innerHTML = "Resume"
        x = true;
        }else{
            Interval = setInterval(stratTimer,1000);
            stopBtn.innerHTML = "Stop";
            x = false;
        }
    })

    //rest function
    resetBtn.addEventListener("click", () => {
        location.reload();
    })
}}
}, {once:true});






